import pytesseract
from pdf2image import convert_from_bytes
from fastapi import UploadFile
from PIL import Image

async def convert_to_raw_text(file: UploadFile) -> str:
    content = await file.read()

    if file.content_type == "application/pdf":
        images = convert_from_bytes(content)
        text = ""
        for image in images:
            text += pytesseract.image_to_string(image)
    elif file.content_type in ["image/jpeg", "image/png"]:
        image = Image.open(file.file)
        text = pytesseract.image_to_string(image)
    else:
        raise ValueError("Unsupported file type for OCR")
    
    return text
