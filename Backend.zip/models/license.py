from pydantic import BaseModel

class LicenseData(BaseModel):
    name: str
    license_number: str
