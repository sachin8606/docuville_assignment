# database/connection.py
from pymongo import MongoClient

client = MongoClient("mongodb://localhost:27017/")
db = client["docuville_db"]
license_collection = db["licenses"]
