from fastapi import FastAPI, File, UploadFile, HTTPException, Form
from fastapi.middleware.cors import CORSMiddleware
from models.license import LicenseData
from services.ocr_service import convert_to_raw_text
from database.connection import license_collection

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"], 
    allow_credentials=True,
    allow_methods=["*"], 
    allow_headers=["*"], 
)

@app.post("/upload-license/")
async def upload_license(
    license_number: str = Form(...),
    name: str = Form(...),
    file: UploadFile = File(...)
):
    if file.content_type not in ["application/pdf", "image/jpeg", "image/png"]:
        raise HTTPException(status_code=400, detail="Invalid file format. Only PDF and image files are allowed.")

    extracted_text = await convert_to_raw_text(file)
    print(f"{extracted_text},{name}")
    try:
        if name in extracted_text and license_number in extracted_text:
            license_data = LicenseData(name=name, license_number=license_number)
            result = license_collection.insert_one(license_data.dict())
            return {"message": "License data verified and stored successfully", "id": str(result.inserted_id)}
        else:
            return {"message": "License verification failed. License number or name not found in document."}
    except Exception as e:
        print(e)
